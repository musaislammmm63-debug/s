# OkTime - Minigames + Practice PvP (Paper plugin)

Targets **Paper 1.21.11** (Java 21). Everything (world, lobby, arenas, GUIs) is generated automatically - no admin setup.

## 1) Get the jar
**Option A - GitHub (no installs):** create a free GitHub repo, upload this whole folder, open the *Actions* tab ->
"Build OkTime" -> download the `OkTime-jar` artifact (contains `OkTime.jar`).

**Option B - on your PC:** install JDK 21 + Maven, open a terminal in this folder, run `mvn package`.
The jar is `target/OkTime.jar`.

## 2) Install
1. Stop the server.
2. Put `OkTime.jar` in `<server folder>/plugins/`.
3. Put `server-icon.png` in the server's root folder (next to `server.properties`).
4. (Optional) in `server.properties` set:
   `motd=&b&lOkTime &8» &fMinigames &7& &fPractice PvP`  (the plugin also sets the MOTD itself)
   `server-name`/display name: OkTime
5. Start the server. In the console you should see `OkTime enabled!`, and a new world folder `oktime` appears.
6. Join: you land in the lobby with the hub items.

## Features
- **Lobby** (auto-built): hotbar menu, scoreboard, tab header.
- **Minigame Wheel** (nether star): spin -> TNT Run / Spleef / Sumo FFA (min 2 players, 15s countdown).
- **Practice PvP**: Unranked + Ranked (ELO) queues, kits: NoDebuff, Gapple, Combo, Archer, Sumo.
- **Kit Editor** (book): rearrange kit layouts, `/savekit`, `/resetkit`.
- **Duels**: `/duel <player>` -> kit picker -> clickable accept.
- **Parties**: party menu (name tag) or `/party create|invite|accept|leave|list|duel <leader>`.
- Commands: /hub /wheel /ranked /unranked /kiteditor /savekit /resetkit /leave /duel /party

## Server description (for server lists)
OkTime - Spin the wheel for chaotic minigames (TNT Run, Spleef, Sumo) or jump into practice PvP with ranked
queues, premade + custom kits, parties and duels. Fast queues, clean UI, no griefing - just fun.
