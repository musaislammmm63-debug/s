package net.oktime;

import net.kyori.adventure.text.event.ClickEvent;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static net.oktime.OkTime.c;
import static net.oktime.OkTime.item;

public final class Duels implements Listener {

    // ================================================================ Kits
    public enum Kit {
        NODEBUFF("NoDebuff", Material.SPLASH_POTION, false, 20, "Diamond gear, speed + health pots, pearls"),
        GAPPLE("Gapple", Material.GOLDEN_APPLE, false, 20, "Diamond gear and golden apples"),
        COMBO("Combo", Material.COOKED_BEEF, false, 0, "No hit delay - pure combos"),
        ARCHER("Archer", Material.BOW, false, 20, "Bow + iron gear"),
        SUMO("Sumo", Material.LEAD, true, 20, "Push your opponent off the platform");

        public final String label;
        final Material icon;
        final boolean sumo;
        final int hitDelay;
        final String desc;

        Kit(String label, Material icon, boolean sumo, int hitDelay, String desc) {
            this.label = label;
            this.icon = icon;
            this.sumo = sumo;
            this.hitDelay = hitDelay;
            this.desc = desc;
        }

        String key() { return name().toLowerCase(); }

        int half() { return sumo ? 5 : 14; }

        private static ItemStack gear(Material m, Enchantment e, int lvl) {
            ItemStack i = new ItemStack(m);
            ItemMeta mt = i.getItemMeta();
            if (e != null && lvl > 0) mt.addEnchant(e, lvl, true);
            mt.setUnbreakable(true);
            i.setItemMeta(mt);
            return i;
        }

        private static ItemStack splash(PotionType t) {
            ItemStack i = new ItemStack(Material.SPLASH_POTION);
            PotionMeta m = (PotionMeta) i.getItemMeta();
            m.setBasePotionType(t);
            i.setItemMeta(m);
            return i;
        }

        /** boots, leggings, chestplate, helmet */
        ItemStack[] armor() {
            switch (this) {
                case SUMO:
                    return new ItemStack[4];
                case ARCHER:
                    return new ItemStack[]{gear(Material.IRON_BOOTS, Enchantment.PROTECTION, 1), gear(Material.IRON_LEGGINGS, Enchantment.PROTECTION, 1),
                            gear(Material.IRON_CHESTPLATE, Enchantment.PROTECTION, 1), gear(Material.IRON_HELMET, Enchantment.PROTECTION, 1)};
                default:
                    return new ItemStack[]{gear(Material.DIAMOND_BOOTS, Enchantment.PROTECTION, 2), gear(Material.DIAMOND_LEGGINGS, Enchantment.PROTECTION, 2),
                            gear(Material.DIAMOND_CHESTPLATE, Enchantment.PROTECTION, 2), gear(Material.DIAMOND_HELMET, Enchantment.PROTECTION, 2)};
            }
        }

        /** 36 slots: 0-8 hotbar, 9-35 main inventory */
        ItemStack[] storage() {
            ItemStack[] s = new ItemStack[36];
            switch (this) {
                case NODEBUFF -> {
                    s[0] = gear(Material.DIAMOND_SWORD, Enchantment.SHARPNESS, 1);
                    s[1] = new ItemStack(Material.ENDER_PEARL, 16);
                    s[2] = splash(PotionType.STRONG_SWIFTNESS);
                    s[3] = splash(PotionType.STRONG_SWIFTNESS);
                    for (int i = 4; i < 36; i++) s[i] = splash(PotionType.STRONG_HEALING);
                }
                case GAPPLE -> {
                    s[0] = gear(Material.DIAMOND_SWORD, Enchantment.SHARPNESS, 1);
                    s[1] = new ItemStack(Material.GOLDEN_APPLE, 16);
                }
                case COMBO -> {
                    s[0] = gear(Material.DIAMOND_SWORD, Enchantment.SHARPNESS, 1);
                    s[1] = new ItemStack(Material.GOLDEN_APPLE, 32);
                }
                case ARCHER -> {
                    ItemStack bow = gear(Material.BOW, Enchantment.POWER, 2);
                    ItemMeta m = bow.getItemMeta();
                    m.addEnchant(Enchantment.INFINITY, 1, true);
                    bow.setItemMeta(m);
                    s[0] = bow;
                    s[1] = gear(Material.STONE_SWORD, null, 0);
                    s[2] = new ItemStack(Material.GOLDEN_APPLE, 4);
                    s[9] = new ItemStack(Material.ARROW, 1);
                }
                case SUMO -> { }
            }
            return s;
        }
    }

    // ================================================================ State
    private record Target(UUID id, boolean party) { }

    private static final class Req {
        final UUID from;
        final Kit kit;
        final boolean party;
        final long expire;

        Req(UUID from, Kit kit, boolean party) {
            this.from = from;
            this.kit = kit;
            this.party = party;
            this.expire = System.currentTimeMillis() + 60_000L;
        }
    }

    private static final class Party {
        UUID leader;
        final Set<UUID> members = new LinkedHashSet<>();

        Party(UUID l) {
            leader = l;
            members.add(l);
        }
    }

    private static final class Match {
        final Kit kit;
        final boolean ranked;
        final List<List<UUID>> teams;
        final Set<UUID> alive = new LinkedHashSet<>();
        final Set<UUID> all = new LinkedHashSet<>();
        final Map<UUID, String> names = new HashMap<>();
        final int idx;
        final Location base;
        boolean started, over;
        BukkitTask ticker;

        Match(Kit kit, boolean ranked, List<List<UUID>> teams, int idx, Location base) {
            this.kit = kit;
            this.ranked = ranked;
            this.teams = teams;
            this.idx = idx;
            this.base = base;
        }
    }

    private final OkTime pl;
    private final Map<String, Deque<UUID>> queues = new HashMap<>();
    private final Map<UUID, String> queued = new HashMap<>();
    private final Map<UUID, Match> matches = new HashMap<>();
    private final Deque<Integer> freeIdx = new ArrayDeque<>();
    private int nextIdx = 0;
    private final Map<UUID, Req> reqs = new HashMap<>();
    private final Map<UUID, Party> parties = new HashMap<>();
    private final Map<UUID, UUID> invites = new HashMap<>();
    private final Map<UUID, Kit> editing = new HashMap<>();

    public Duels(OkTime pl) { this.pl = pl; }

    public int queued() { return queued.size(); }

    public int fighting() { return matches.size(); }

    private World w() { return pl.lobby.world; }

    private void later(Runnable r) { Bukkit.getScheduler().runTask(pl, r); }

    private static void fill(Inventory inv) {
        ItemStack g = item(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, g);
    }

    // ================================================================ ELO
    private int elo(UUID u, Kit k) { return pl.data.getInt("elo." + u + "." + k.key(), 1000); }

    private void setElo(UUID u, Kit k, int v) { pl.data.set("elo." + u + "." + k.key(), v); }

    // ================================================================ Menus
    private Kit kitAt(int slot) {
        int i = slot - 11;
        Kit[] ks = Kit.values();
        return (i >= 0 && i < ks.length) ? ks[i] : null;
    }

    public void openKitMenu(Player p, boolean ranked) {
        Gui g = new Gui("kits", 27, c(ranked ? "&b&lRanked Queue" : "&a&lUnranked Queue"), ranked);
        Inventory inv = g.getInventory();
        fill(inv);
        int i = 11;
        for (Kit k : Kit.values()) {
            String key = k.key() + ":" + ranked;
            int q = queues.containsKey(key) ? queues.get(key).size() : 0;
            int f = 0;
            for (Match m : matches.values()) if (m.kit == k) f++;
            List<String> lore = new ArrayList<>();
            lore.add("&7" + k.desc);
            lore.add(" ");
            lore.add("&7Queued: &b" + q + "  &7Fighting: &b" + f);
            if (ranked) lore.add("&7Your ELO: &e" + elo(p.getUniqueId(), k));
            lore.add(" ");
            lore.add("&a\u25B6 Click to queue");
            inv.setItem(i++, item(k.icon, "&b&l" + k.label, lore.toArray(new String[0])));
        }
        p.openInventory(inv);
    }

    public void openEditorMenu(Player p) {
        Gui g = new Gui("editor", 27, c("&e&lKit Editor"), null);
        Inventory inv = g.getInventory();
        fill(inv);
        int i = 11;
        for (Kit k : Kit.values()) {
            inv.setItem(i++, item(k.icon, "&e&l" + k.label, "&7Rearrange your hotbar & inventory", "&a\u25B6 Click to edit"));
        }
        p.openInventory(inv);
    }

    private void openTargetMenu(Player p, Target t) {
        Gui g = new Gui("duelkit", 27, c("&c&lChoose a kit to duel with"), t);
        Inventory inv = g.getInventory();
        fill(inv);
        int i = 11;
        for (Kit k : Kit.values()) inv.setItem(i++, item(k.icon, "&c&l" + k.label, "&7" + k.desc, " ", "&a\u25B6 Click to send challenge"));
        p.openInventory(inv);
    }

    public void openPartyMenu(Player p) {
        Party pt = parties.get(p.getUniqueId());
        Gui g = new Gui("party", 27, c("&d&lParty"), null);
        Inventory inv = g.getInventory();
        fill(inv);
        if (pt == null) {
            inv.setItem(13, item(Material.NAME_TAG, "&a&lCreate Party", "&7Click to create a party"));
        } else {
            List<String> names = new ArrayList<>();
            for (UUID u : pt.members) {
                names.add((u.equals(pt.leader) ? "&6\u2605 " : "&7- ") + "&f" + Bukkit.getOfflinePlayer(u).getName());
            }
            inv.setItem(11, item(Material.PLAYER_HEAD, "&b&lInvite Players", "&7Click to pick an online player"));
            inv.setItem(13, item(Material.BOOK, "&d&lMembers", names.toArray(new String[0])));
            inv.setItem(15, item(Material.BARRIER, pt.leader.equals(p.getUniqueId()) ? "&c&lDisband Party" : "&c&lLeave Party"));
            if (pt.leader.equals(p.getUniqueId())) inv.setItem(22, item(Material.IRON_SWORD, "&6&lParty vs Party", "&7Use &f/party duel <leader>"));
        }
        p.openInventory(inv);
    }

    private void openInviteMenu(Player p) {
        List<UUID> list = new ArrayList<>();
        Gui g = new Gui("pinv", 54, c("&b&lInvite to party"), list);
        Inventory inv = g.getInventory();
        int slot = 0;
        for (Player t : Bukkit.getOnlinePlayers()) {
            if (t.equals(p) || parties.containsKey(t.getUniqueId()) || slot >= 54) continue;
            ItemStack h = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) h.getItemMeta();
            sm.setOwningPlayer(t);
            sm.displayName(c("&b" + t.getName()));
            sm.lore(List.of(c("&aClick to invite")));
            h.setItemMeta(sm);
            inv.setItem(slot, h);
            list.add(t.getUniqueId());
            slot++;
        }
        p.openInventory(inv);
    }

    @SuppressWarnings("unchecked")
    public void guiClick(Player p, Gui g, int slot) {
        switch (g.id) {
            case "kits" -> {
                Kit k = kitAt(slot);
                if (k == null) return;
                boolean ranked = (Boolean) g.data;
                later(() -> { p.closeInventory(); enqueue(p, k, ranked); });
            }
            case "editor" -> {
                Kit k = kitAt(slot);
                if (k == null) return;
                later(() -> { p.closeInventory(); beginEdit(p, k); });
            }
            case "duelkit" -> {
                Kit k = kitAt(slot);
                if (k == null) return;
                Target t = (Target) g.data;
                later(() -> { p.closeInventory(); sendRequest(p, t, k); });
            }
            case "party" -> {
                Party pt = parties.get(p.getUniqueId());
                if (pt == null && slot == 13) {
                    later(() -> { createParty(p); openPartyMenu(p); });
                } else if (pt != null && slot == 11) {
                    later(() -> openInviteMenu(p));
                } else if (pt != null && slot == 15) {
                    later(() -> { p.closeInventory(); leaveParty(p); });
                }
            }
            case "pinv" -> {
                List<UUID> list = (List<UUID>) g.data;
                if (slot >= 0 && slot < list.size()) {
                    Player t = Bukkit.getPlayer(list.get(slot));
                    later(() -> { p.closeInventory(); if (t != null) invite(p, t); });
                }
            }
            default -> { }
        }
    }

    // ================================================================ Queue
    public void enqueue(Player p, Kit kit, boolean ranked) {
        if (!pl.isFree(p)) return;
        UUID id = p.getUniqueId();
        pl.games.leave(p);
        dequeue(p);
        String key = kit.key() + ":" + ranked;
        Deque<UUID> q = queues.computeIfAbsent(key, k -> new ArrayDeque<>());
        UUID opp = null;
        while (!q.isEmpty()) {
            UUID u = q.poll();
            Player o = Bukkit.getPlayer(u);
            if (o != null && !u.equals(id) && queued.containsKey(u) && pl.isFree(o)) {
                opp = u;
                break;
            }
        }
        if (opp != null) {
            queued.remove(opp);
            List<List<UUID>> teams = new ArrayList<>();
            teams.add(List.of(id));
            teams.add(List.of(opp));
            startMatch(kit, ranked, teams);
        } else {
            q.add(id);
            queued.put(id, key);
            pl.markQueued(p);
            p.sendMessage(c("&aQueued for &b" + kit.label + (ranked ? " &7(Ranked)" : " &7(Unranked)") + "&a. Searching for an opponent..."));
        }
    }

    public void dequeue(Player p) {
        String key = queued.remove(p.getUniqueId());
        if (key != null) {
            Deque<UUID> q = queues.get(key);
            if (q != null) q.remove(p.getUniqueId());
        }
    }

    // ================================================================ Requests / duel command
    public void cmdDuel(Player p, String[] a) {
        if (a.length == 0) {
            p.sendMessage(c("&cUsage: &f/duel <player> &7or &f/duel accept <player>"));
            return;
        }
        if (a[0].equalsIgnoreCase("accept")) {
            if (a.length < 2) { p.sendMessage(c("&cUsage: /duel accept <player>")); return; }
            accept(p, a[1]);
            return;
        }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null || t.equals(p)) { p.sendMessage(c("&cPlayer not found.")); return; }
        if (!pl.isFree(p) || !pl.isFree(t)) { p.sendMessage(c("&cYou or that player is busy right now.")); return; }
        openTargetMenu(p, new Target(t.getUniqueId(), false));
    }

    private void sendRequest(Player p, Target t, Kit k) {
        Player target = Bukkit.getPlayer(t.id());
        if (target == null || !pl.isFree(p) || !pl.isFree(target)) {
            p.sendMessage(c("&cThat player isn't available."));
            return;
        }
        reqs.put(target.getUniqueId(), new Req(p.getUniqueId(), k, t.party()));
        p.sendMessage(c("&aChallenge sent to &f" + target.getName() + " &7(" + k.label + (t.party() ? ", party" : "") + ")"));
        target.sendMessage(c("&e" + p.getName() + " &7challenged you to &b" + k.label + (t.party() ? " &7(party vs party)" : "") + "! ")
                .append(c("&a&l[ACCEPT]").clickEvent(ClickEvent.runCommand("/duel accept " + p.getName()))));
        target.playSound(target.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
    }

    private List<UUID> freeMembers(Party pt) {
        List<UUID> l = new ArrayList<>();
        for (UUID u : pt.members) {
            Player m = Bukkit.getPlayer(u);
            if (m != null && pl.isFree(m)) l.add(u);
        }
        return l;
    }

    private void accept(Player p, String name) {
        Player from = Bukkit.getPlayerExact(name);
        Req r = reqs.get(p.getUniqueId());
        if (from == null || r == null || !r.from.equals(from.getUniqueId()) || r.expire < System.currentTimeMillis()) {
            p.sendMessage(c("&cNo valid challenge from that player."));
            return;
        }
        reqs.remove(p.getUniqueId());
        if (!pl.isFree(from) || !pl.isFree(p)) {
            p.sendMessage(c("&cOne of you is busy right now."));
            return;
        }
        List<UUID> ta, tb;
        if (r.party) {
            Party pa = parties.get(from.getUniqueId()), pb = parties.get(p.getUniqueId());
            if (pa == null || pb == null) { p.sendMessage(c("&cBoth leaders need a party.")); return; }
            ta = freeMembers(pa);
            tb = freeMembers(pb);
        } else {
            ta = List.of(from.getUniqueId());
            tb = List.of(p.getUniqueId());
        }
        List<List<UUID>> teams = new ArrayList<>();
        teams.add(ta);
        teams.add(tb);
        startMatch(r.kit, false, teams);
    }

    // ================================================================ Parties
    private void createParty(Player p) {
        if (parties.containsKey(p.getUniqueId())) { p.sendMessage(c("&cYou're already in a party.")); return; }
        parties.put(p.getUniqueId(), new Party(p.getUniqueId()));
        p.sendMessage(c("&dParty created! Invite players with the party menu or &f/party invite <name>"));
    }

    private void invite(Player p, Player t) {
        Party pt = parties.get(p.getUniqueId());
        if (pt == null || !pt.leader.equals(p.getUniqueId())) { p.sendMessage(c("&cOnly the party leader can invite.")); return; }
        if (parties.containsKey(t.getUniqueId())) { p.sendMessage(c("&cThat player is already in a party.")); return; }
        invites.put(t.getUniqueId(), p.getUniqueId());
        p.sendMessage(c("&dInvited &f" + t.getName() + "&d to your party."));
        t.sendMessage(c("&d" + p.getName() + " &7invited you to their party! ")
                .append(c("&a&l[JOIN]").clickEvent(ClickEvent.runCommand("/party accept " + p.getName()))));
    }

    private void partyMsg(Party pt, String s) {
        for (UUID u : pt.members) {
            Player m = Bukkit.getPlayer(u);
            if (m != null) m.sendMessage(c(s));
        }
    }

    private void leaveParty(Player p) {
        Party pt = parties.get(p.getUniqueId());
        if (pt == null) return;
        if (pt.leader.equals(p.getUniqueId())) {
            partyMsg(pt, "&dThe party was disbanded.");
            for (UUID u : new ArrayList<>(pt.members)) parties.remove(u);
        } else {
            pt.members.remove(p.getUniqueId());
            parties.remove(p.getUniqueId());
            p.sendMessage(c("&dYou left the party."));
            partyMsg(pt, "&d" + p.getName() + " left the party.");
        }
    }

    public void cmdParty(Player p, String[] a) {
        String sub = a.length == 0 ? "menu" : a[0].toLowerCase();
        switch (sub) {
            case "create" -> createParty(p);
            case "invite" -> {
                Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : null;
                if (t == null || t.equals(p)) p.sendMessage(c("&cPlayer not found.")); else invite(p, t);
            }
            case "accept" -> {
                Player l = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : null;
                UUID inv = invites.get(p.getUniqueId());
                Party pt = l == null ? null : parties.get(l.getUniqueId());
                if (l == null || inv == null || !inv.equals(l.getUniqueId()) || pt == null) { p.sendMessage(c("&cNo valid invite.")); return; }
                if (parties.containsKey(p.getUniqueId())) { p.sendMessage(c("&cYou're already in a party.")); return; }
                invites.remove(p.getUniqueId());
                pt.members.add(p.getUniqueId());
                parties.put(p.getUniqueId(), pt);
                partyMsg(pt, "&d" + p.getName() + " joined the party!");
            }
            case "leave", "disband" -> leaveParty(p);
            case "list" -> {
                Party pt = parties.get(p.getUniqueId());
                if (pt == null) { p.sendMessage(c("&cYou're not in a party.")); return; }
                StringBuilder sb = new StringBuilder("&dParty: ");
                for (UUID u : pt.members) sb.append(u.equals(pt.leader) ? "&6\u2605" : "&f").append(Bukkit.getOfflinePlayer(u).getName()).append(" ");
                p.sendMessage(c(sb.toString()));
            }
            case "duel" -> {
                Party pt = parties.get(p.getUniqueId());
                Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : null;
                if (pt == null || !pt.leader.equals(p.getUniqueId())) { p.sendMessage(c("&cOnly a party leader can start party duels.")); return; }
                Party other = t == null ? null : parties.get(t.getUniqueId());
                if (other == null || !other.leader.equals(t.getUniqueId())) { p.sendMessage(c("&cTarget must be another party's leader.")); return; }
                openTargetMenu(p, new Target(t.getUniqueId(), true));
            }
            default -> {
                if (sub.equals("menu")) { openPartyMenu(p); return; }
                p.sendMessage(c("&d/party create | invite <p> | accept <p> | leave | list | duel <leader>"));
            }
        }
    }

    // ================================================================ Kit editor
    private ItemStack[] custom(UUID u, Kit k) {
        List<?> l = pl.data.getList("kits." + u + "." + k.key());
        if (l == null || l.size() != 36) return null;
        ItemStack[] out = new ItemStack[36];
        for (int i = 0; i < 36; i++) {
            Object o = l.get(i);
            out[i] = (o instanceof ItemStack is && is.getType() != Material.AIR) ? is : null;
        }
        return out;
    }

    private void beginEdit(Player p, Kit k) {
        if (!pl.isFree(p)) return;
        pl.leaveQueue(p);
        pl.states.put(p.getUniqueId(), OkTime.State.EDITOR);
        editing.put(p.getUniqueId(), k);
        PlayerInventory inv = p.getInventory();
        inv.clear();
        inv.setArmorContents(k.armor());
        ItemStack[] st = custom(p.getUniqueId(), k);
        inv.setStorageContents(st == null ? k.storage() : st);
        p.sendMessage(c("&eEditing &b" + k.label + "&e. Rearrange your hotbar & inventory, then type &a/savekit &e(or &c/resetkit&e, &c/hub &eto cancel)."));
    }

    public void saveKit(Player p) {
        Kit k = editing.get(p.getUniqueId());
        if (k == null || pl.state(p) != OkTime.State.EDITOR) { p.sendMessage(c("&cYou're not editing a kit. Use the Kit Editor.")); return; }
        ItemStack[] st = p.getInventory().getStorageContents();
        List<ItemStack> out = new ArrayList<>();
        for (int i = 0; i < 36; i++) out.add(i < st.length && st[i] != null ? st[i] : new ItemStack(Material.AIR));
        pl.data.set("kits." + p.getUniqueId() + "." + k.key(), out);
        pl.saveData();
        p.sendMessage(c("&aSaved your &b" + k.label + " &alayout!"));
        pl.toLobby(p);
    }

    public void resetKit(Player p) {
        Kit k = editing.get(p.getUniqueId());
        if (k == null || pl.state(p) != OkTime.State.EDITOR) { p.sendMessage(c("&cYou're not editing a kit.")); return; }
        pl.data.set("kits." + p.getUniqueId() + "." + k.key(), null);
        pl.saveData();
        p.getInventory().setStorageContents(k.storage());
        p.sendMessage(c("&aKit reset to default."));
    }

    // ================================================================ Matches
    private void startMatch(Kit kit, boolean ranked, List<List<UUID>> raw) {
        List<List<UUID>> teams = new ArrayList<>();
        for (List<UUID> t : raw) {
            List<UUID> l = new ArrayList<>();
            for (UUID u : t) if (Bukkit.getPlayer(u) != null) l.add(u);
            teams.add(l);
        }
        if (teams.get(0).isEmpty() || teams.get(1).isEmpty()) return;

        int idx = freeIdx.isEmpty() ? nextIdx++ : freeIdx.pop();
        Location base = new Location(w(), 5000 + idx * 100, 100, 0);
        Match m = new Match(kit, ranked, teams, idx, base);
        build(m, false);

        for (int ti = 0; ti < 2; ti++) {
            List<UUID> team = teams.get(ti);
            for (int j = 0; j < team.size(); j++) {
                Player p = Bukkit.getPlayer(team.get(j));
                UUID id = team.get(j);
                m.alive.add(id);
                m.all.add(id);
                m.names.put(id, p.getName());
                matches.put(id, m);
                pl.leaveQueue(p);
                pl.states.put(id, OkTime.State.DUEL);
                prepare(p, kit);
                p.teleport(spawn(m, ti, j, team.size()));
            }
        }

        new BukkitRunnable() {
            int t = 5;

            @Override
            public void run() {
                if (m.over) { cancel(); return; }
                if (t == 0) {
                    cancel();
                    m.started = true;
                    for (UUID u : m.all) {
                        Player p = Bukkit.getPlayer(u);
                        if (p != null) {
                            OkTime.title(p, "&a&lFIGHT!", "&7" + kit.label);
                            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.2f);
                        }
                    }
                    return;
                }
                for (UUID u : m.all) {
                    Player p = Bukkit.getPlayer(u);
                    if (p != null) {
                        OkTime.title(p, "&e&l" + t, "&7" + describe(m));
                        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1f);
                    }
                }
                t--;
            }
        }.runTaskTimer(pl, 0L, 20L);

        m.ticker = new BukkitRunnable() {
            @Override
            public void run() {
                if (m.over) { cancel(); return; }
                for (UUID u : new ArrayList<>(m.alive)) {
                    Player p = Bukkit.getPlayer(u);
                    if (p != null && p.getLocation().getY() < m.base.getY() - 6) eliminate(m, p, null);
                }
            }
        }.runTaskTimer(pl, 0L, 5L);
    }

    private String describe(Match m) {
        String a = m.names.get(m.teams.get(0).get(0));
        String b = m.names.get(m.teams.get(1).get(0));
        return m.teams.get(0).size() > 1 || m.teams.get(1).size() > 1 ? "Party vs Party" : a + " vs " + b;
    }

    private void prepare(Player p, Kit k) {
        for (PotionEffect ef : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(ef.getType());
        p.setGameMode(GameMode.SURVIVAL);
        p.setInvulnerable(false);
        p.setHealth(20);
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.setMaximumNoDamageTicks(k.hitDelay);
        PlayerInventory inv = p.getInventory();
        inv.clear();
        inv.setItemInOffHand(new ItemStack(Material.AIR));
        inv.setArmorContents(k.armor());
        ItemStack[] st = custom(p.getUniqueId(), k);
        inv.setStorageContents(st == null ? k.storage() : st);
        inv.setHeldItemSlot(0);
    }

    private Location spawn(Match m, int ti, int j, int n) {
        int h = m.kit.half();
        double x = m.base.getBlockX() + 0.5 + (ti == 0 ? -(h - 2) : (h - 2));
        double z = m.base.getBlockZ() + 0.5 + (j - (n - 1) / 2.0) * 2;
        return new Location(w(), x, 101, z, ti == 0 ? -90f : 90f, 0f);
    }

    private void build(Match m, boolean clear) {
        int cx = m.base.getBlockX(), cz = m.base.getBlockZ(), h = m.kit.half();
        for (int x = -h - 1; x <= h + 1; x++) {
            for (int z = -h - 1; z <= h + 1; z++) {
                if (clear) {
                    for (int y = 100; y <= 104; y++) w().getBlockAt(cx + x, y, cz + z).setType(Material.AIR, false);
                    continue;
                }
                if (Math.abs(x) > h || Math.abs(z) > h) continue;
                boolean ring = Math.abs(x) == h || Math.abs(z) == h;
                Material fl;
                if (m.kit.sumo) fl = ring ? Material.RED_CONCRETE : (Math.floorMod(x + z, 2) == 0 ? Material.WHITE_CONCRETE : Material.LIGHT_GRAY_CONCRETE);
                else fl = ring ? Material.BLACK_CONCRETE : (Math.floorMod(x + z, 2) == 0 ? Material.POLISHED_ANDESITE : Material.POLISHED_DIORITE);
                w().getBlockAt(cx + x, 100, cz + z).setType(fl, false);
                if (ring && !m.kit.sumo) {
                    for (int y = 101; y <= 103; y++) w().getBlockAt(cx + x, y, cz + z).setType(Material.GLASS, false);
                }
            }
        }
    }

    private int teamOf(Match m, UUID u) {
        return m.teams.get(0).contains(u) ? 0 : 1;
    }

    private void eliminate(Match m, Player p, UUID killer) {
        UUID id = p.getUniqueId();
        if (m.over || !m.alive.remove(id)) return;
        p.setHealth(20);
        p.setGameMode(GameMode.SPECTATOR);
        p.teleport(new Location(w(), m.base.getX() + 0.5, 108, m.base.getZ() + 0.5));
        OkTime.title(p, "&c&lDEFEAT", "&7You were eliminated");
        w().strikeLightningEffect(p.getLocation());
        String by = killer == null ? "" : " &7by &b" + m.names.getOrDefault(killer, "?");
        for (UUID u : m.all) {
            Player o = Bukkit.getPlayer(u);
            if (o != null) o.sendMessage(c("&c" + p.getName() + " &7was eliminated" + by + "&7."));
        }
        int win = -1;
        for (int ti = 0; ti < 2; ti++) {
            boolean any = false;
            for (UUID u : m.teams.get(ti)) if (m.alive.contains(u)) any = true;
            if (!any) win = 1 - ti;
        }
        if (win >= 0) end(m, win);
    }

    private void end(Match m, int win) {
        m.over = true;
        if (m.ticker != null) m.ticker.cancel();
        StringBuilder names = new StringBuilder();
        for (UUID u : m.teams.get(win)) names.append(m.names.get(u)).append(" ");
        for (UUID u : m.all) {
            Player p = Bukkit.getPlayer(u);
            if (p == null) continue;
            boolean won = m.teams.get(win).contains(u);
            if (won) {
                p.setInvulnerable(true);
                OkTime.title(p, "&a&lVICTORY", "&7You won!");
            }
            p.sendMessage(c("&6&l" + names.toString().trim() + " &ewon the duel!"));
        }
        if (m.ranked && m.teams.get(0).size() == 1 && m.teams.get(1).size() == 1) {
            UUID wi = m.teams.get(win).get(0), lo = m.teams.get(1 - win).get(0);
            int rw = elo(wi, m.kit), rl = elo(lo, m.kit);
            double ew = 1.0 / (1 + Math.pow(10, (rl - rw) / 400.0));
            int d = Math.max(1, (int) Math.round(32 * (1 - ew)));
            setElo(wi, m.kit, rw + d);
            setElo(lo, m.kit, Math.max(0, rl - d));
            pl.saveData();
            Player pw = Bukkit.getPlayer(wi), pn = Bukkit.getPlayer(lo);
            if (pw != null) pw.sendMessage(c("&aELO: &f" + (rw + d) + " &a(+" + d + ")"));
            if (pn != null) pn.sendMessage(c("&cELO: &f" + Math.max(0, rl - d) + " &c(-" + d + ")"));
        }
        Bukkit.getScheduler().runTaskLater(pl, () -> finish(m), 80L);
    }

    private void finish(Match m) {
        for (UUID u : new ArrayList<>(m.all)) {
            matches.remove(u);
            Player p = Bukkit.getPlayer(u);
            if (p != null) pl.toLobby(p);
        }
        build(m, true);
        for (Entity en : w().getNearbyEntities(new Location(w(), m.base.getX(), 105, m.base.getZ()), 40, 30, 40)) {
            if (!(en instanceof Player)) en.remove();
        }
        freeIdx.push(m.idx);
    }

    /** Called when a player leaves a match (hub command / quit). Counts as a loss. */
    public void leave(Player p) {
        dequeue(p);
        Match m = matches.remove(p.getUniqueId());
        editing.remove(p.getUniqueId());
        if (m != null && !m.over && m.alive.contains(p.getUniqueId())) {
            // mark gone, then evaluate result
            m.alive.remove(p.getUniqueId());
            for (UUID u : m.all) {
                Player o = Bukkit.getPlayer(u);
                if (o != null && !o.equals(p)) o.sendMessage(c("&c" + p.getName() + " &7left the match."));
            }
            int win = -1;
            for (int ti = 0; ti < 2; ti++) {
                boolean any = false;
                for (UUID u : m.teams.get(ti)) if (m.alive.contains(u)) any = true;
                if (!any) win = 1 - ti;
            }
            if (win >= 0) end(m, win);
        }
    }

    public void handleQuit(Player p) {
        leave(p);
        leaveParty(p);
        reqs.remove(p.getUniqueId());
        invites.remove(p.getUniqueId());
    }

    // ================================================================ Events
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (pl.state(p) != OkTime.State.DUEL) return;
        Match m = matches.get(p.getUniqueId());
        if (m == null || !m.started || m.over || !m.alive.contains(p.getUniqueId())) {
            e.setCancelled(true);
            return;
        }
        UUID killer = null;
        if (e instanceof EntityDamageByEntityEvent be) {
            Player d = null;
            if (be.getDamager() instanceof Player dp) d = dp;
            else if (be.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player sp) d = sp;
            if (d != null && !d.equals(p)) {
                if (!m.alive.contains(d.getUniqueId()) || teamOf(m, d.getUniqueId()) == teamOf(m, p.getUniqueId())) {
                    e.setCancelled(true);
                    return;
                }
                killer = d.getUniqueId();
            }
            if (m.kit.sumo) {
                e.setDamage(0);
                return;
            }
        } else if (m.kit.sumo) {
            e.setCancelled(true);
            return;
        }
        if (p.getHealth() - e.getFinalDamage() <= 0) {
            e.setCancelled(true);
            eliminate(m, p, killer);
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (pl.state(p) != OkTime.State.DUEL) return;
        Match m = matches.get(p.getUniqueId());
        if (m == null || m.started) return;
        Location f = e.getFrom(), t = e.getTo();
        if (f.getX() != t.getX() || f.getZ() != t.getZ()) {
            Location n = f.clone();
            n.setYaw(t.getYaw());
            n.setPitch(t.getPitch());
            e.setTo(n);
        }
    }
}
