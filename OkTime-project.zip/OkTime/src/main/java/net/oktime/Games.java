package net.oktime;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import static net.oktime.OkTime.c;
import static net.oktime.OkTime.item;

public final class Games implements Listener {

    public enum Type {
        TNT_RUN("TNT Run", Material.TNT, 0, 88),
        SPLEEF("Spleef", Material.DIAMOND_SHOVEL, 300, 88),
        SUMO("Sumo FFA", Material.SLIME_BALL, 600, 95);

        final String label;
        final Material icon;
        final int z;
        final int killY;

        Type(String label, Material icon, int z, int killY) {
            this.label = label;
            this.icon = icon;
            this.z = z;
            this.killY = killY;
        }
    }

    private static final int MIN = 2, MAX = 16, CX = 1000;

    private static final class Arena {
        final Type type;
        final Set<UUID> waiting = new LinkedHashSet<>();
        final Set<UUID> alive = new LinkedHashSet<>();
        final Set<UUID> part = new LinkedHashSet<>();
        final Set<Block> pending = new HashSet<>();
        boolean busy, running;
        BukkitTask countdown, ticker;

        Arena(Type t) { this.type = t; }
    }

    private final OkTime pl;
    private final Map<Type, Arena> arenas = new EnumMap<>(Type.class);
    private final Map<UUID, Arena> of = new HashMap<>();
    private final Random rand = new Random();

    public Games(OkTime pl) {
        this.pl = pl;
        for (Type t : Type.values()) arenas.put(t, new Arena(t));
    }

    private World w() { return pl.lobby.world; }

    private Location center(Type t) { return new Location(w(), CX + 0.5, 100, t.z + 0.5); }

    public int playing() {
        int n = 0;
        for (Arena a : arenas.values()) if (a.busy) n += a.alive.size();
        return n;
    }

    public int waitingCount() {
        int n = 0;
        for (Arena a : arenas.values()) n += a.waiting.size();
        return n;
    }

    // ---------------------------------------------------------------- Wheel
    public void openWheel(Player p) {
        Gui g = new Gui("wheel", 27, c("&6&lMinigame Wheel"), null);
        Inventory inv = g.getInventory();
        ItemStack glass = item(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, glass);
        inv.setItem(4, item(Material.LIME_STAINED_GLASS_PANE, "&a&l\u25BC"));
        inv.setItem(22, item(Material.LIME_STAINED_GLASS_PANE, "&a&l\u25B2"));
        Type[] ts = Type.values();
        render(inv, ts, 0);
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1f, 1f);

        final int n = ts.length;
        final Type target = ts[rand.nextInt(n)];
        int base = 36;
        final int total = base + Math.floorMod(target.ordinal() - 4 - base, n);

        new BukkitRunnable() {
            int step = 0, tick = 0;

            @Override
            public void run() {
                if (!p.isOnline() || !(p.getOpenInventory().getTopInventory().getHolder() instanceof Gui gg) || !gg.id.equals("wheel")) {
                    cancel();
                    return;
                }
                tick++;
                int interval = 1 + (step * step) / 150;
                if (tick < interval) return;
                tick = 0;
                if (step >= total) {
                    cancel();
                    p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
                    OkTime.title(p, "&6&l" + target.label, "&7Joining...");
                    Bukkit.getScheduler().runTaskLater(pl, () -> {
                        if (!p.isOnline()) return;
                        p.closeInventory();
                        join(p, target);
                    }, 40L);
                    return;
                }
                step++;
                render(inv, ts, step);
                p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1.3f);
            }
        }.runTaskTimer(pl, 0L, 1L);
    }

    private void render(Inventory inv, Type[] ts, int step) {
        for (int i = 0; i < 9; i++) {
            Type t = ts[(step + i) % ts.length];
            ItemStack it = item(t.icon, (i == 4 ? "&6&l" : "&7") + t.label);
            if (i == 4) {
                ItemMeta m = it.getItemMeta();
                m.addEnchant(Enchantment.UNBREAKING, 1, true);
                it.setItemMeta(m);
            }
            inv.setItem(9 + i, it);
        }
    }

    // ---------------------------------------------------------------- Join / leave
    public void join(Player p, Type t) {
        UUID id = p.getUniqueId();
        pl.duels.dequeue(p);
        if (!pl.isFree(p)) return;
        leave(p);
        Arena a = arenas.get(t);
        a.waiting.add(id);
        of.put(id, a);
        pl.markQueued(p);
        p.sendMessage(c("&aYou joined the &6" + t.label + " &aqueue. &7(" + a.waiting.size() + "/" + MAX + ")"));
        if (a.busy) p.sendMessage(c("&7A round is in progress - you'll play in the next one."));
        else if (a.waiting.size() < MIN) p.sendMessage(c("&7Waiting for more players (need " + MIN + ")..."));
        tryStart(a);
    }

    /** Removes the player from any minigame (waiting or playing). Does not teleport. Returns true if they were in one. */
    public boolean leave(Player p) {
        UUID id = p.getUniqueId();
        Arena a = of.remove(id);
        if (a == null) return false;
        a.waiting.remove(id);
        if (a.part.contains(id)) {
            if (a.running && a.alive.contains(id)) eliminate(a, p, true);
            a.alive.remove(id);
            a.part.remove(id);
        }
        return true;
    }

    private void tryStart(Arena a) {
        if (a.busy || a.countdown != null || a.waiting.size() < MIN) return;
        a.countdown = new BukkitRunnable() {
            int t = 15;

            @Override
            public void run() {
                if (a.waiting.size() < MIN) {
                    cancel();
                    a.countdown = null;
                    msg(a.waiting, "&cNot enough players. Waiting...");
                    return;
                }
                if (t == 0) {
                    cancel();
                    a.countdown = null;
                    start(a);
                    return;
                }
                if (t <= 5 || t == 10 || t == 15) {
                    msg(a.waiting, "&e" + a.type.label + " starts in &b" + t + "s");
                    for (UUID u : a.waiting) {
                        Player p = Bukkit.getPlayer(u);
                        if (p != null) p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1f);
                    }
                }
                t--;
            }
        }.runTaskTimer(pl, 0L, 20L);
    }

    private void msg(Set<UUID> set, String s) {
        for (UUID u : new ArrayList<>(set)) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) p.sendMessage(c(s));
        }
    }

    // ---------------------------------------------------------------- Round
    private void start(Arena a) {
        a.busy = true;
        a.running = true;
        build(a.type);
        List<UUID> picked = new ArrayList<>();
        for (UUID u : a.waiting) {
            if (picked.size() >= MAX) break;
            picked.add(u);
        }
        a.waiting.removeAll(picked);
        a.alive.addAll(picked);
        a.part.addAll(picked);
        int i = 0;
        for (UUID u : picked) {
            Player p = Bukkit.getPlayer(u);
            if (p == null) {
                a.alive.remove(u);
                a.part.remove(u);
                of.remove(u);
                continue;
            }
            pl.states.put(u, OkTime.State.GAME);
            prepare(p, a.type);
            p.teleport(spawn(a.type, i++, picked.size()));
            OkTime.title(p, "&6&l" + a.type.label, a.type == Type.SUMO ? "&7Knock everyone off!" : "&7Last one standing wins!");
        }
        a.ticker = new BukkitRunnable() {
            @Override
            public void run() { tick(a); }
        }.runTaskTimer(pl, 0L, 1L);
        checkEnd(a);
    }

    private Location spawn(Type t, int i, int n) {
        double r = switch (t) { case TNT_RUN -> 9; case SPLEEF -> 8; case SUMO -> 3.5; };
        double ang = 2 * Math.PI * i / Math.max(1, n);
        Location l = new Location(w(), CX + 0.5 + Math.cos(ang) * r, 101, t.z + 0.5 + Math.sin(ang) * r);
        l.setDirection(center(t).add(0, 1, 0).toVector().subtract(l.toVector()));
        return l;
    }

    private void prepare(Player p, Type t) {
        p.getInventory().clear();
        p.getInventory().setArmorContents(new ItemStack[4]);
        for (PotionEffect ef : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(ef.getType());
        p.setGameMode(GameMode.SURVIVAL);
        p.setHealth(20);
        p.setFoodLevel(20);
        p.setFireTicks(0);
        if (t == Type.SPLEEF) {
            ItemStack s = new ItemStack(Material.DIAMOND_SHOVEL);
            ItemMeta m = s.getItemMeta();
            m.displayName(c("&b&lSpleef Shovel"));
            m.addEnchant(Enchantment.EFFICIENCY, 5, true);
            m.setUnbreakable(true);
            s.setItemMeta(m);
            p.getInventory().setItem(0, s);
        }
    }

    private void tick(Arena a) {
        if (!a.running) return;
        List<Player> fallen = new ArrayList<>();
        for (UUID u : a.alive) {
            Player p = Bukkit.getPlayer(u);
            if (p == null) continue;
            Location l = p.getLocation();
            if (l.getY() < a.type.killY) {
                fallen.add(p);
                continue;
            }
            if (a.type == Type.TNT_RUN) {
                for (double dx : new double[]{-0.3, 0.3}) {
                    for (double dz : new double[]{-0.3, 0.3}) {
                        Block b = l.clone().add(dx, -0.5, dz).getBlock();
                        if (b.getType() == Material.YELLOW_CONCRETE && a.pending.add(b)) {
                            Bukkit.getScheduler().runTaskLater(pl, () -> {
                                b.setType(Material.AIR, false);
                                a.pending.remove(b);
                            }, 8L);
                        }
                    }
                }
            }
        }
        for (Player p : fallen) eliminate(a, p, false);
    }

    private void eliminate(Arena a, Player p, boolean silent) {
        UUID id = p.getUniqueId();
        if (!a.alive.remove(id)) return;
        if (!silent) {
            p.setGameMode(GameMode.SPECTATOR);
            p.teleport(center(a.type).add(0, 14, 0));
            OkTime.title(p, "&c&lEliminated", "&7Better luck next time!");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
        }
        msg(a.part, "&7" + p.getName() + " &cwas eliminated &8(" + a.alive.size() + " left)");
        checkEnd(a);
    }

    private void checkEnd(Arena a) {
        if (!a.running || a.alive.size() > 1) return;
        a.running = false;
        if (a.ticker != null) a.ticker.cancel();
        UUID win = a.alive.isEmpty() ? null : a.alive.iterator().next();
        Player wp = win == null ? null : Bukkit.getPlayer(win);
        String name = wp == null ? "Nobody" : wp.getName();
        for (UUID u : new ArrayList<>(a.part)) {
            Player p = Bukkit.getPlayer(u);
            if (p == null) continue;
            p.sendMessage(c("&6&l" + name + " &ewon &6" + a.type.label + "&e!"));
            OkTime.title(p, "&6&l" + name, "&eWon the game!");
        }
        if (wp != null) wp.setInvulnerable(true);
        Bukkit.getScheduler().runTaskLater(pl, () -> finish(a), 100L);
    }

    private void finish(Arena a) {
        for (UUID u : new ArrayList<>(a.part)) {
            of.remove(u);
            a.part.remove(u);
            Player p = Bukkit.getPlayer(u);
            if (p != null) pl.toLobby(p);
        }
        a.alive.clear();
        a.pending.clear();
        clear(a.type);
        a.busy = false;
        tryStart(a);
    }

    // ---------------------------------------------------------------- Arenas
    private void set(int x, int y, int z, Material m) {
        w().getBlockAt(x, y, z).setType(m, false);
    }

    private void build(Type t) {
        int z0 = t.z;
        switch (t) {
            case TNT_RUN -> {
                for (int x = -12; x <= 12; x++)
                    for (int z = -12; z <= 12; z++) {
                        set(CX + x, 100, z0 + z, Material.YELLOW_CONCRETE);
                        set(CX + x, 94, z0 + z, Material.YELLOW_CONCRETE);
                    }
            }
            case SPLEEF -> {
                for (int x = -14; x <= 14; x++)
                    for (int z = -14; z <= 14; z++)
                        if (x * x + z * z <= 14 * 14) {
                            set(CX + x, 100, z0 + z, Material.SNOW_BLOCK);
                            set(CX + x, 94, z0 + z, Material.SNOW_BLOCK);
                        }
            }
            case SUMO -> {
                for (int x = -7; x <= 7; x++)
                    for (int z = -7; z <= 7; z++) {
                        double d = Math.sqrt(x * x + z * z);
                        if (d <= 7) {
                            Material m = d > 6 ? Material.RED_CONCRETE
                                    : (Math.floorMod(x + z, 2) == 0 ? Material.WHITE_CONCRETE : Material.LIGHT_GRAY_CONCRETE);
                            set(CX + x, 100, z0 + z, m);
                        }
                    }
            }
        }
    }

    private void clear(Type t) {
        for (int x = -16; x <= 16; x++)
            for (int z = -16; z <= 16; z++)
                for (int y = 93; y <= 100; y++)
                    set(CX + x, y, t.z + z, Material.AIR);
    }

    // ---------------------------------------------------------------- Events
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (pl.state(p) != OkTime.State.GAME) return;
        Arena a = of.get(p.getUniqueId());
        if (a != null && a.running && a.type == Type.SUMO && a.alive.contains(p.getUniqueId())
                && e instanceof EntityDamageByEntityEvent) {
            e.setDamage(0); // knockback only
            return;
        }
        e.setCancelled(true);
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (pl.state(p) != OkTime.State.GAME) return;
        Arena a = of.get(p.getUniqueId());
        boolean ok = a != null && a.running && a.type == Type.SPLEEF && a.alive.contains(p.getUniqueId())
                && e.getBlock().getType() == Material.SNOW_BLOCK;
        e.setCancelled(!ok);
        if (ok) e.setDropItems(false);
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (pl.state(e.getPlayer()) == OkTime.State.GAME) e.setCancelled(true);
    }
}
