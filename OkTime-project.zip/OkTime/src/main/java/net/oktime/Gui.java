package net.oktime;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class Gui implements InventoryHolder {
    public final String id;
    public final Object data;
    private final Inventory inv;

    public Gui(String id, int size, Component title, Object data) {
        this.id = id;
        this.data = data;
        this.inv = Bukkit.createInventory(this, size, title);
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }
}
