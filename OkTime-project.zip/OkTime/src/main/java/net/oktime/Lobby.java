package net.oktime;

import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.Random;

import static net.oktime.OkTime.State;

public final class Lobby implements Listener {
    private final OkTime pl;
    public final World world;
    private final Location spawn;

    /** Completely empty (void) world. Everything is built by code. */
    static final class VoidGen extends ChunkGenerator {
        @Override
        public Location getFixedSpawnLocation(World w, Random r) {
            return new Location(w, 0.5, 101, 0.5);
        }
    }

    public Lobby(OkTime pl) {
        this.pl = pl;
        World w = Bukkit.getWorld("oktime");
        if (w == null) {
            w = new WorldCreator("oktime").generator(new VoidGen()).generateStructures(false).createWorld();
        }
        this.world = w;
        this.spawn = new Location(world, 0.5, 101, 0.5, 0, 0);
        world.setSpawnLocation(0, 101, 0);
        world.setDifficulty(Difficulty.NORMAL);
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        world.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS, false);
        world.setGameRule(GameRule.DO_FIRE_TICK, false);
        world.setTime(6000);
        world.setStorm(false);
        if (world.getBlockAt(0, 100, 0).getType() == Material.AIR) build();
    }

    public Location spawn() { return spawn.clone(); }

    private void set(int x, int y, int z, Material m) {
        world.getBlockAt(x, y, z).setType(m, false);
    }

    private void build() {
        for (int x = -24; x <= 24; x++) {
            for (int z = -24; z <= 24; z++) {
                double d = Math.sqrt(x * x + z * z);
                if (d <= 22) {
                    Material m;
                    if (d <= 1.5) m = Material.SEA_LANTERN;
                    else if (d <= 6) m = Material.LIGHT_BLUE_CONCRETE;
                    else if (d <= 7) m = Material.WHITE_CONCRETE;
                    else if (d > 20.5) m = Material.POLISHED_BLACKSTONE;
                    else m = (Math.floorMod(x + z, 2) == 0) ? Material.POLISHED_ANDESITE : Material.POLISHED_DIORITE;
                    set(x, 100, z, m);
                } else if (d <= 23) {
                    for (int y = 101; y <= 105; y++) set(x, y, z, Material.BARRIER);
                }
            }
        }
        int[][] pillars = {{14, 14}, {-14, 14}, {14, -14}, {-14, -14}};
        for (int[] p : pillars) {
            for (int y = 101; y <= 105; y++) set(p[0], y, p[1], Material.QUARTZ_PILLAR);
            set(p[0], 106, p[1], Material.SEA_LANTERN);
        }
    }

    // ---------- protection ----------
    private boolean creative(Player p) { return p.getGameMode() == GameMode.CREATIVE; }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (creative(p) || pl.state(p) == State.GAME) return;
        e.setCancelled(true);
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (creative(p)) return;
        e.setCancelled(true);
    }

    @EventHandler
    public void onHunger(FoodLevelChangeEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (!creative(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && !creative(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        State s = pl.state(e.getPlayer());
        if (s == State.LOBBY || s == State.QUEUE) e.setCancelled(true);
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) {
            State s = pl.state(p);
            if (s == State.LOBBY || s == State.QUEUE || s == State.EDITOR) e.setCancelled(true);
        }
    }

    @EventHandler
    public void onSpawn(CreatureSpawnEvent e) {
        if (e.getLocation().getWorld().equals(world)) e.setCancelled(true);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (e.getTo().getY() < 80) {
            State s = pl.state(p);
            if (s == State.LOBBY || s == State.QUEUE || s == State.EDITOR) p.teleport(spawn());
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        InventoryHolder h = e.getView().getTopInventory().getHolder();
        if (h instanceof Gui g) {
            e.setCancelled(true);
            if (e.getWhoClicked() instanceof Player p && e.getClickedInventory() != null
                    && e.getClickedInventory().equals(e.getView().getTopInventory())) {
                pl.duels.guiClick(p, g, e.getSlot());
            }
            return;
        }
        if (e.getWhoClicked() instanceof Player p && !creative(p)) {
            State s = pl.state(p);
            if (s == State.LOBBY || s == State.QUEUE) e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Gui) {
            e.setCancelled(true);
            return;
        }
        if (e.getWhoClicked() instanceof Player p && !creative(p)) {
            State s = pl.state(p);
            if (s == State.LOBBY || s == State.QUEUE) e.setCancelled(true);
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        if (!pl.isFree(p)) return;
        ItemStack it = e.getItem();
        if (it == null) return;
        switch (it.getType()) {
            case IRON_SWORD -> { e.setCancelled(true); pl.duels.openKitMenu(p, false); }
            case DIAMOND_SWORD -> { e.setCancelled(true); pl.duels.openKitMenu(p, true); }
            case NETHER_STAR -> { e.setCancelled(true); pl.games.openWheel(p); }
            case NAME_TAG -> { e.setCancelled(true); pl.duels.openPartyMenu(p); }
            case BOOK -> { e.setCancelled(true); pl.duels.openEditorMenu(p); }
            case REDSTONE -> { e.setCancelled(true); pl.leaveQueue(p); }
            default -> { }
        }
    }
}
