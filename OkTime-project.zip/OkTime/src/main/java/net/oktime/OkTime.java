package net.oktime;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.server.ServerListPingEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class OkTime extends JavaPlugin implements Listener {

    public enum State { LOBBY, QUEUE, DUEL, GAME, EDITOR }

    private static OkTime inst;
    public static OkTime get() { return inst; }

    public final Map<UUID, State> states = new HashMap<>();
    private final Map<UUID, Scoreboard> boards = new HashMap<>();
    public Lobby lobby;
    public Games games;
    public Duels duels;
    public YamlConfiguration data;
    private File dataFile;

    private static final String[] CMDS = {"hub", "wheel", "ranked", "unranked", "kiteditor", "savekit", "resetkit", "leave", "duel", "party"};

    // ---------- helpers ----------
    public static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    public static ItemStack item(Material m, String name, String... lore) {
        ItemStack i = new ItemStack(m);
        ItemMeta mt = i.getItemMeta();
        mt.displayName(c(name));
        if (lore.length > 0) mt.lore(Arrays.stream(lore).map(OkTime::c).toList());
        mt.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        i.setItemMeta(mt);
        return i;
    }

    public static void title(Player p, String t, String s) {
        p.showTitle(Title.title(c(t), c(s), Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(1), Duration.ofMillis(300))));
    }

    public void saveData() {
        try { data.save(dataFile); } catch (IOException ex) { getLogger().warning("Could not save data.yml: " + ex.getMessage()); }
    }

    public State state(Player p) { return states.getOrDefault(p.getUniqueId(), State.LOBBY); }

    public boolean isFree(Player p) {
        State s = state(p);
        return s == State.LOBBY || s == State.QUEUE;
    }

    // ---------- lifecycle ----------
    @Override
    public void onEnable() {
        inst = this;
        getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);

        lobby = new Lobby(this);
        games = new Games(this);
        duels = new Duels(this);

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(lobby, this);
        getServer().getPluginManager().registerEvents(games, this);
        getServer().getPluginManager().registerEvents(duels, this);

        for (String n : CMDS) {
            PluginCommand pc = getCommand(n);
            if (pc != null) pc.setExecutor(this);
        }
        getServer().getScheduler().runTaskTimer(this, this::updateBoards, 20L, 40L);
        for (Player p : Bukkit.getOnlinePlayers()) toLobby(p);
        getLogger().info("OkTime enabled!");
    }

    @Override
    public void onDisable() {
        saveData();
    }

    // ---------- lobby handling ----------
    public void toLobby(Player p) {
        duels.leave(p);
        games.leave(p);
        p.closeInventory();
        states.put(p.getUniqueId(), State.LOBBY);
        for (PotionEffect ef : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(ef.getType());
        p.setGameMode(GameMode.ADVENTURE);
        p.setInvulnerable(false);
        p.setMaximumNoDamageTicks(20);
        p.setHealth(20);
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.setLevel(0);
        p.setExp(0f);
        p.setAllowFlight(false);
        p.setFlying(false);
        p.teleport(lobby.spawn());
        giveHub(p);
    }

    public void giveHub(Player p) {
        var inv = p.getInventory();
        inv.clear();
        inv.setArmorContents(new ItemStack[4]);
        inv.setItemInOffHand(new ItemStack(Material.AIR));
        inv.setItem(0, item(Material.IRON_SWORD, "&a&lUnranked Duels &7(Right Click)", "&7Casual 1v1 matches"));
        inv.setItem(1, item(Material.DIAMOND_SWORD, "&b&lRanked Duels &7(Right Click)", "&7Climb the ELO ladder"));
        inv.setItem(2, item(Material.NETHER_STAR, "&6&lMinigame Wheel &7(Right Click)", "&7Spin to pick a minigame!"));
        inv.setItem(4, item(Material.NAME_TAG, "&d&lParty &7(Right Click)", "&7Create or manage your party"));
        inv.setItem(7, item(Material.BOOK, "&e&lKit Editor &7(Right Click)", "&7Customise your kit layouts"));
        inv.setHeldItemSlot(0);
    }

    public void leaveQueue(Player p) {
        duels.dequeue(p);
        games.leave(p);
        if (state(p) == State.QUEUE) {
            states.put(p.getUniqueId(), State.LOBBY);
            p.getInventory().setItem(8, null);
            p.sendMessage(c("&cYou left the queue."));
        }
    }

    public void markQueued(Player p) {
        states.put(p.getUniqueId(), State.QUEUE);
        p.getInventory().setItem(8, item(Material.REDSTONE, "&c&lLeave Queue &7(Right Click)"));
    }

    // ---------- scoreboard ----------
    private void updateBoards() {
        int online = Bukkit.getOnlinePlayers().size();
        for (Player p : Bukkit.getOnlinePlayers()) {
            Scoreboard sb = boards.computeIfAbsent(p.getUniqueId(), k -> Bukkit.getScoreboardManager().getNewScoreboard());
            Objective o = sb.getObjective("oktime");
            if (o == null) {
                o = sb.registerNewObjective("oktime", Criteria.DUMMY, c("&b&lOkTime"));
                o.setDisplaySlot(DisplaySlot.SIDEBAR);
            }
            for (String e : new ArrayList<>(sb.getEntries())) sb.resetScores(e);
            String[] lines = {
                    "&7 ",
                    "&fOnline: &b" + online,
                    "&fIn Queue: &b" + (duels.queued() + games.waitingCount()),
                    "&fDuelling: &b" + duels.fighting(),
                    "&fMinigames: &b" + games.playing(),
                    "&8 ",
                    "&bPlay at OkTime!"
            };
            int score = lines.length;
            for (String l : lines) o.getScore(l.replace('&', '\u00a7')).setScore(score--);
            p.setScoreboard(sb);
            p.sendPlayerListHeaderAndFooter(c("\n&b&lOkTime\n&7Minigames & Practice PvP\n"), c("\n&7Spin the wheel &8| &7Queue a duel &8| &7Make a party\n"));
        }
    }

    // ---------- events ----------
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        e.joinMessage(c("&8[&a+&8] &7" + p.getName()));
        Bukkit.getScheduler().runTask(this, () -> {
            toLobby(p);
            title(p, "&b&lOkTime", "&7Minigames &8\u2022 &7Practice PvP");
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        e.quitMessage(c("&8[&c-&8] &7" + p.getName()));
        duels.handleQuit(p);
        games.leave(p);
        states.remove(p.getUniqueId());
        boards.remove(p.getUniqueId());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        e.setRespawnLocation(lobby.spawn());
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(this, () -> toLobby(p));
    }

    @EventHandler
    public void onPing(ServerListPingEvent e) {
        e.motd(c("&b&lOkTime &8\u00bb &fMinigames &7& &fPractice PvP\n&7Spin the wheel &8\u2022 &7Queue duels &8\u2022 &7Make a party"));
    }

    // ---------- commands ----------
    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof Player p)) {
            s.sendMessage("Players only.");
            return true;
        }
        switch (cmd.getName().toLowerCase()) {
            case "hub" -> toLobby(p);
            case "wheel" -> { if (isFree(p)) games.openWheel(p); else p.sendMessage(c("&cFinish what you're doing first (/hub).")); }
            case "ranked" -> { if (isFree(p)) duels.openKitMenu(p, true); else p.sendMessage(c("&cYou can't do that right now.")); }
            case "unranked" -> { if (isFree(p)) duels.openKitMenu(p, false); else p.sendMessage(c("&cYou can't do that right now.")); }
            case "kiteditor" -> { if (isFree(p)) duels.openEditorMenu(p); else p.sendMessage(c("&cYou can't do that right now.")); }
            case "savekit" -> duels.saveKit(p);
            case "resetkit" -> duels.resetKit(p);
            case "leave" -> {
                State st = state(p);
                if (st == State.GAME || st == State.DUEL || st == State.EDITOR) toLobby(p); else leaveQueue(p);
            }
            case "duel" -> duels.cmdDuel(p, a);
            case "party" -> duels.cmdParty(p, a);
            default -> { }
        }
        return true;
    }
}
